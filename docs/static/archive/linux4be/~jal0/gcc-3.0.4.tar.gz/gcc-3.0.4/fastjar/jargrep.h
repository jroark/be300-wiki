/*
  jargrep.h - header file for jargrep utility
  Copyright (C) 2000 Cory Hollingsworth

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/*$Id: jargrep.h,v 1.1 2000/12/09 03:08:23 apbianco Exp $
*/

#define JG_PRINT_BYTEOFFSET		0x00000001
#define JG_PRINT_COUNT			0x00000002
#define JG_IGNORE_CASE			0x00000004
#define JG_PRINT_LINE_NUMBER	0x00000008
#define JG_SUPRESS_ERROR		0x00000010
#define JG_INVERT				0x00000020
#define JG_WORD_EXPRESSIONS		0x00000040

#define GVERSION "jargrep version 0.1 (09/12/2000)"
