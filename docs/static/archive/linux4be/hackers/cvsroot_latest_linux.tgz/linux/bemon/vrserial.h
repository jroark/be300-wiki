#ifndef _VRSERIAL_H
#define _VRSERIAL_H


#define NEC41XX_SIU_BASE  (0x0a008680 + 0xa0000000)
/*
 * These are the UART port assignments, expressed as offsets from the base
 * register.  These assignments should hold for any serial port based on
 * a 8250, 16450, or 16550(A).
*/
#define UART_RX		0x00	/* In:  Receive buffer (DLAB=0) */
#define UART_TX		0x00	/* Out: Transmit buffer (DLAB=0) */
#define UART_DLL	0x00	/* Out: Divisor Latch Low (DLAB=1) */
#define UART_DLM	0x01	/* Out: Divisor Latch High (DLAB=1) */

//ns
#define UART_IER	0x04	/* Out: Interrupt Enable Register */

//ns
#define UART_IIR	0x08	/* In:  Interrupt ID Register */

#define UART_LCR	0x03	/* Out: Line Control Register */

//ns
#define UART_MCR	0x10	/* Out: Modem Control Register */

//ns
#define UART_LSR	0x14	/* In:  Line Status Register */

#define UART_MSR	0x06	/* In:  Modem Status Register */

/* Physical Address of registers */
#define NEC41XX_UART_RX  (UART_RX  + NEC41XX_SIU_BASE)
#define NEC41XX_UART_TX  (UART_TX  + NEC41XX_SIU_BASE)
#define NEC41XX_UART_DLL (UART_DLL + NEC41XX_SIU_BASE)
#define NEC41XX_UART_DLM (UART_DLM + NEC41XX_SIU_BASE)
#define NEC41XX_UART_IER (UART_IER + NEC41XX_SIU_BASE)
#define NEC41XX_UART_IIR (UART_IIR + NEC41XX_SIU_BASE)
#define NEC41XX_UART_LCR (UART_LCR + NEC41XX_SIU_BASE)
#define NEC41XX_UART_MCR (UART_MCR + NEC41XX_SIU_BASE)
#define NEC41XX_UART_LSR (UART_LSR + NEC41XX_SIU_BASE)
#define NEC41XX_UART_MSR (UART_MSR + NEC41XX_SIU_BASE)

/*
 * These are the definitions for the Line Control Register
 *
 * Note: if the word length is 5 bits (UART_LCR_WLEN5), then setting
 * UART_LCR_STOP will select 1.5 stop bits, not 2 stop bits.
 */
#define UART_LCR_WLEN5  0x00	/* Wordlength: 5 bits */
#define UART_LCR_WLEN6  0x01	/* Wordlength: 6 bits */
#define UART_LCR_WLEN7  0x02	/* Wordlength: 7 bits */
#define UART_LCR_WLEN8  0x03	/* Wordlength: 8 bits */
#define UART_LCR_STOP	0x04	/* Stop bits: 0=1 stop bit, 1= 2 stop bits */
#define UART_LCR_PARITY	0x08	/* Parity Enable */
#define UART_LCR_EPAR	0x10	/* Even parity select */
#define UART_LCR_SPAR	0x20	/* Stick parity (?) */
#define UART_LCR_SBC	0x40	/* Set break control */
#define UART_LCR_DLAB	0x80	/* Divisor latch access bit */

#define NO_PARITY       0x00
#define EVEN_PARITY     0x18
#define ODD_PARITY      0x08

/*
 * These are the definitions for the Line Status Register
 */
#define UART_LSR_DR		0x01	/* Receiver data ready */
#define UART_LSR_OE		0x02	/* Overrun error indicator */
#define UART_LSR_PE		0x04	/* Parity error indicator */
#define UART_LSR_FE		0x08	/* Frame error indicator */
#define UART_LSR_BI		0x10	/* Break interrupt indicator */
#define UART_LSR_THRE	0x20	/* Transmit-hold-register empty */
#define UART_LSR_TEMT	0x40	/* Transmitter empty */

/*
 * These are the definitions for the Modem Control Register
 */
#define UART_MCR_DTR	0x01	/* DTR complement */
#define UART_MCR_RTS	0x02	/* RTS complement */
#define UART_MCR_OUT1	0x04	/* Out1 complement */
#define UART_MCR_OUT2	0x08	/* Out2 complement */
#define UART_MCR_LOOP	0x10	/* Enable loopback test mode */

#define UART_MCR_INT	0x08

/*
 * These are the definitions for the Modem Status Register
 */
#define UART_MSR_DCTS		0x01	/* Delta CTS */
#define UART_MSR_DDSR		0x02	/* Delta DSR */
#define UART_MSR_TERI		0x04	/* Trailing edge ring indicator */
#define UART_MSR_DDCD		0x08	/* Delta DCD */
#define UART_MSR_ANY_DELTA 	0x0F	/* Any of the delta bits! */
#define UART_MSR_CTS		0x10	/* Clear to Send */
#define UART_MSR_DSR		0x20	/* Data Set Ready */
#define UART_MSR_RI			0x40	/* Ring Indicator */
#define UART_MSR_DCD		0x80	/* Data Carrier Detect */

/*
 * These are the definitions for the Interrupt Identification Register
 */
#define UART_IIR_NO_INT	0x01	/* No interrupts pending */
#define UART_IIR_ID		0x06	/* Mask for the interrupt ID */

#define UART_IIR_MSI	0x00	/* Modem status interrupt */
#define UART_IIR_THRI	0x02	/* Transmitter holding register empty */
#define UART_IIR_RDI	0x04	/* Receiver data interrupt */
#define UART_IIR_RLSI	0x06	/* Receiver line status interrupt */

/*
 * These are the definitions for the Interrupt Enable Register
 */
#define UART_IER_MSI	0x08	/* Enable Modem status interrupt */
#define UART_IER_RLSI	0x04	/* Enable receiver line status interrupt */
#define UART_IER_THRI	0x02	/* Enable Transmitter holding register int. */
#define UART_IER_RDI	0x01	/* Enable receiver data interrupt */

#endif
