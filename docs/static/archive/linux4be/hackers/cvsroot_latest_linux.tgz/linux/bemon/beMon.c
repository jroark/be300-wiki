#define TRUE	1
#define FALSE	0
#define CR 		0x0d

/*	Flag definations	*/
#define OK	0
#define	NODATA	1		/* Returns from getHex when no data found */

extern int	SerialInBlocking(void);
extern int	SerialIn(void);
extern int	SerialOut(char x);
extern void SerialOutString(char *string);

/* Print a new line seq.	*/
__inline__ void
crlf(void) { SerialOutString("\n\r"); }

/* Sends a bell character (may not be supported by all host terminals) */
__inline__ void
bell(void) { SerialOut(0x07); }

/* Returns true if c is lower case */
int islower (int c)
{
	if (c >= 'a' && c <= 'z')
		return (TRUE);
	return (FALSE);
}

/* Returns true if c is decimal digit */
int isdigit (int c)
{
	if (c >= '0' && c <= '9')
		return (TRUE);
	return (FALSE);
}

/* Translate character to uppercase */
int
toupper(int c)
{
	if (islower(c))  /* is it lower case */
    	return (c - ('a' - 'A'));
	return (c);
}

/* convert a string to uppercase */
char *
upcase(char *str)
{
	char *start;
	start = str;

	while (*str)
	{
		if (islower(*str))
			*str = toupper(*str);
		str++;
	}
	return(start);
}

/* convert string to long integer assuming string has radix */
int
stol(char *str,unsigned int radix)
{
	unsigned int digit;
	unsigned long number = 0;

	while (*str)
	{
		if (isdigit(*str))
			digit = *str - '0';
		else if (islower(digit))
			digit = *str - 'a' + 10;
		else
			digit = *str - 'A' + 10;

		number = number * radix + digit;
		str++;
	}
	return(number);
}

/* itob -- convert an integer to a string in any base (2-36)
   where
	n is the number to convert
	s is a temp. string
	base is the number base
*/
char*
ltos(long n, char *s, int base)
{
	char *p = s, *q = s;
	int c;

	/* generate digits in reverse order */
	do
	{
		if ( (*p = ((unsigned)n % base) + '0') > '9' )
			*p += ('A' - ('9' + 1));

		++p;
	}while (((unsigned)n = (unsigned)n / base) > 0);

	*p = 0;    // null-terminate the string

	/* reverse the digits */
	while (q < --p)
	{
		c = *q;
		*q++ = *p;
		*p = c;
	}

	return(s);
}


/* Returns the length of a string */
char
len(char * s)
{
	char i = 0;

	while(*s++)
		i++;
	return i;
}

/* Get hexadecimal value from serial port */
unsigned long
getHex(void)
{
	char c=0;
	unsigned long val;
	int cnt = 0;
	char temp[10];

	while( c != CR )
	{
		c = SerialInBlocking();

		temp[cnt++] = c;

		if( (cnt>8) & (c != CR) )
		{
			bell();
			cnt--;
		}
		else
		{
			SerialOut(c);
		}

		/*	Back space occured	*/
		if( c == '\b' )
		{
			if(cnt>0)
			{
				cnt--;
				SerialOutString(" \b");
			}
			else
				bell();
		}
	}

	/* replace trailing cr with end of string marker */
	temp[--cnt]=0;

	upcase(temp);

	val = stol(temp,16);

	return(val);
}

/*	Send char. s n times over the serial line	*/
void
rept(char s,char n)
{
	if(n==0) return;
	while(n--)
		SerialOut(s);
}

/* Print x spaces	*/
void
space(char x)
{
	if(x==0)
		return;

	while (x--)
		SerialOut(' ');
}

/* phex(n,len,spc)
 * print in hex the number (n) 0 filled of len with spc trailing
 * spaces. phex(100,4,2) will print '0064  '.
*/
void
phex(long n,unsigned char lgth,unsigned char spc)
{
	char temp[10];
	int tempLength;
	char *tempPtr;

	ltos(n,temp,16);

	tempLength=len(temp);

	if(tempLength > lgth)
	{
		tempPtr = (&temp[tempLength] - lgth);
	}
	else
	{
		tempPtr=&temp[0];
		rept('0',(lgth-tempLength));	/* 0 fill	*/
	}

	SerialOutString(tempPtr);

	space(spc);			/* print sep.	 */
	/* Print the 16 hex digits */
}

/* pascii(char,fill,spc)
	print ascii or fill and spc traiing spaces
*/
void
pascii(unsigned char chr,unsigned char fill,unsigned char spc)
{
	if(chr<' ' || chr>'}')
		SerialOut(fill);
	else
		SerialOut(chr);

	space(spc);
}

/*	Hex dump with address on left and ASCII on right	*/
/*	Start is the begin address and end is the end		*/
void
dump(long start,long end)
{
	int c_cnt;
	long p;

	for ( p=start ; p < end; )
	{
		/* Print the address */
		phex(p,8,4);

		for(c_cnt=0;c_cnt<16;c_cnt++)
		{
			phex( *((unsigned char*)p),2,1);
			p++;
		}

		p-=16;				/* reset */
					/* Print the ASCII	*/
		for(c_cnt=0;c_cnt<16;c_cnt++)
		{
			pascii(*((unsigned char*)p),'.',0);
			p++;
		}

		crlf();
	}
}

/* 	Examine memory	*/
void
examineMem(void)
{
	unsigned long memStart;
	unsigned char* pMemStart;
	__volatile__ long i;

	SerialOutString("xamine  ");

	/* get address */
	memStart = getHex();

	pMemStart = (unsigned char*)memStart;

	crlf();

	/* Print address */
	phex(memStart,8,2);

	/* Print contents */
	i=(long)(*pMemStart & 0xFF);
	phex(i,2,2);
}

/*	Dump memory	*/
void
dumpMem(void)
{
	unsigned long start=0,end=0;

	SerialOutString("ump Start  ");

	/* Get start address*/
	start=getHex();
	crlf();

	SerialOutString(">Dump End  ");

	end=getHex();
	crlf();

	if(end<=start)  /* range check */
	{
		end=start+16;  /* defaults 16-byte dumps */
	}

	dump(start,end);
}


void
beMon(void)
{
	unsigned char c;

	crlf();
	SerialOutString("BE300 Debug Monitor v0.01 by Jal0");

	/* Main Command Loop. Restart with <CTRL-C> */
	while(1)
	{
		crlf();
		SerialOut('>');

		/* Get Command */
		c = toupper( SerialInBlocking() );

		switch(c)
		{
		case 'F':			/* Fill Memory */
			//fillMem();
			break;
		case 'D':			/* Dump Memory */
			SerialOut('D');
			dumpMem();
			break;
		case 'E':			/* Examine Memory */
			SerialOut('E');
			examineMem();
			break;
		case 3:				/* Ctl C  Exit	*/
			return;
		default:
			SerialOutString("ERROR : Unknown Command ");
			SerialOut(c);
			crlf();
			break;

		}
	}
}

