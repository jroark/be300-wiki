#include "vrserial.h"

#define VERSION 0x0001

#define NOERROR         0       	/* No error          */
#define ERROR        	(int)-1     /* An error occured  */


#define outportb(addr,byte) 	(*(unsigned char*)addr=byte)
#define inportb(addr)			(*(unsigned char*)addr)

/* Turn on communications interrupts */
void   i_enable(void)
{
	// To Do....
	return;
}

/* Turn off communications interrupts */
void   i_disable(void)
{
	int c;

    outportb(NEC41XX_UART_IER, 0);

    c = inportb(NEC41XX_UART_MCR) & ~UART_MCR_INT;
   	outportb(NEC41XX_UART_MCR, c);
}

/* Tell modem that we're ready to go */
void   comm_on(void)
{
    int		c;
    int		dummy;

    c = inportb(NEC41XX_UART_MCR) | UART_MCR_DTR | UART_MCR_RTS;

    /* Data Terminal Ready; Computer wants to send data. */
    outportb(NEC41XX_UART_MCR, c);

	/* clear FIFO and disable it */
	//outportb(NEC41XX_UART_FCR, UART_FCR_CLEAR_RCVR | UART_FCR_CLEAR_XMIT);
	//outportb(NEC41XX_UART_FCR,0);

	/* clear any pending ints */
	dummy = inportb(NEC41XX_UART_MSR);
	dummy = inportb(NEC41XX_UART_IIR);
	while ( inportb(NEC41XX_UART_LSR) & UART_LSR_DR )
	{
		dummy = inportb(NEC41XX_UART_RX);
	}

}

/* Go off-line */
void   comm_off(void)
{
    outportb(NEC41XX_UART_MCR, 0);
}

////////////////////////////////////////////////////////////////


/* This routine sets the speed; will accept funny baud rates. */
/* Setting the speed requires that the DLAB be set on.        */
int    SetSpeed(unsigned int Speed)
{
    char	c;
    int		divisor;

    if (Speed == 0)            /* Avoid divide by zero */
        return (ERROR);
    else
        divisor = (int) (1152000L/Speed);

    c = inportb(NEC41XX_UART_LCR);
    outportb(NEC41XX_UART_LCR, (c | 0x80)); /* Set DLAB */
    outportb(NEC41XX_UART_DLL, (divisor & 0x00FF));
    outportb(NEC41XX_UART_DLM, ((divisor >> 8) & 0x00FF));
    outportb(NEC41XX_UART_LCR, c);          /* Reset DLAB */

    return (0);
}

/* Set other communications parameters */
int    SetOthers(int Parity, int Bits, int StopBit)
{
    int                setting;

    if (Bits < 5 || Bits > 8)
    	return (ERROR);

    if (StopBit != 1 && StopBit != 2)
    	return (ERROR);

    if (Parity != NO_PARITY && Parity != ODD_PARITY && Parity != EVEN_PARITY)
		return (ERROR);

    setting  = Bits-5;
    setting |= ((StopBit == 1) ? 0x00 : 0x04);
    setting |= Parity;

    outportb(NEC41XX_UART_LCR, setting);

    return (0);
}

/* Set up the port */
int    SetSerial(unsigned int Speed, int Parity, int Bits, int StopBit)
{
    if (SetSpeed(Speed))                  return (ERROR);
    if (SetOthers(Parity, Bits, StopBit)) return (ERROR);
    return (0);
}

/* Output a character to the serial port */
int    SerialOut(char x)
{
    long int           timeout = 0x0000FFFFL;

	/* Data Terminal Ready; Computer wants to send data. */
    outportb(NEC41XX_UART_MCR,  UART_MCR_DTR | UART_MCR_RTS);

	timeout = 0x0000FFFFL;
    /* Wait for transmitter to clear */
    while ( !(inportb(NEC41XX_UART_LSR) & UART_LSR_THRE) )
    {
        if (!(--timeout))
            return (ERROR);
	}

    outportb(NEC41XX_UART_TX, x);

    return (0);
}

/* Output a string to the serial port */
void   SerialOutString(char *string)
{
    while (*string)
       SerialOut(*string++);
}

/* Recieve a character from the serial port */
int   SerialIn(void)
{
    int 		i = ERROR;

    if( inportb(NEC41XX_UART_LSR) & UART_LSR_DR )
    {
        i = (int) inportb(NEC41XX_UART_RX);
    }

    return i;
}

/* Recieve a character from the serial port (blocking) */
int SerialInBlocking(void)
{
	int c = ERROR;

	while( (c = SerialIn()) == ERROR ){};

	return(c);
}


extern void beMon(void);

void
start(void)
{
	long int    timeout = 0x0000FFFFL;

	i_disable();
	comm_on();

	SetSerial(9600, EVEN_PARITY, 8, 1);

	while(1)
	{
		beMon();
	}

	//////
	// Control Should Never Reach Here !!!!!!!!!!!!!!!!

}
