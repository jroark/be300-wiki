

#define BEVIDEORAM	(0x0a200000 + 0xa0000000)

void start(void)
{
unsigned short x,y;
unsigned short *vbuff;
unsigned short c;

  vbuff=(unsigned short *)0xaa200000;
  for (x=0;x<0xFFFF;x++){
    *(unsigned short*)(vbuff++)=0xf800;
  }

  vbuff=(unsigned short *)0xaa200000;
  for (x=0;x<0xFFFF;x++){
    *(unsigned short*)(vbuff++)=0x001F;
  }

  vbuff=(unsigned short *)0xaa200000;
  for (x=0;x<0xFFFF;x++){
    *(unsigned short*)(vbuff++)=0x07E0;
  }


//  for (x=0;x<0xFF;x++){
//    *(unsigned short*)(0xaa00098c)=x;
//  }

c=1;	
while(1<2)
{
	if (c>0xFFFF)
		c=0;
	
	vbuff=(unsigned short *)0x0a200000;

                for (y=0;y<105;y=y++)
                {
                        for (x=0;x<80;x++)
                        {
				vbuff[256*y+x]=0xF800;
				*(unsigned short*)(0xaa200000+x+y*256)=0xF800;
	                 }
                }
                for (y=0;y<105;y=y++)
                {
                        for (x=160;x<240;x++)
                        {
				vbuff[256*y+x]=c;
				*(unsigned short*)(0xaa200000+x+y*256)=c;
	                 }
                }
                for (y=105;y<210;y=y++)
                {
                        for (x=80;x<160;x++)
                        {
				*(unsigned short*)(0xaa200000+x+y*256)=0x07e0;
				vbuff[256*y+x]=0x07E0;
                        }
                }
                for (y=210;y<320;y=y++)
                {
                        for (x=160;x<240;x++)
                        {
				vbuff[256*y+x]=0x001f;
				*(unsigned short*)(0xaa200000+x+y*256)=0x001F;
                        }
                }
	c++;
        }

}


