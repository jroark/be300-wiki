Dumper
======

Dumper is a Windows CE program to dump the contents of physical memory to files (64KB segments). It reads the settings from an ini-file (see below), and when set to autostart (just copy the exe to \Storage Card\CE\R4100\autorun.exe ), it will continue where it stopped the last time in the event of a crash/exception. 
	 
- dumper.txt
  MUST be in the following location:
		Storage Card\CE\R4100\dumper.txt

- It contains two sections:
 [config]
  with start, end, blocksize, maxattemtps and logfile	

 [session]
  currentstart and currentattempt.


LICENSE
Dumper is Copyright (c)2002 Filip Onkelinx, 
Dumper comes with absolutely no warranty.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


--------------------------------------------------------------------
	
$Id: ReadMe.txt,v 1.3 2002/04/01 20:14:07 filip Exp $
