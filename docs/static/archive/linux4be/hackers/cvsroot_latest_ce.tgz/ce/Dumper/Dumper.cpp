// Project: Linux4.BE
// Copyright � 2002 Filip Onkelinx
//
// http://www.linux4.BE/
// filip@linux4.BE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA. 
//
// 
// $Workfile: $  
// $Author: filip $  
// $Date: 2002/07/09 22:16:13 $
// $Revision: 1.2 $
// 
// $Header: /home/cvsroot/ce/Dumper/Dumper.cpp,v 1.2 2002/07/09 22:16:13 filip Exp $
// 
// -------------------------------------------------------------------------------


#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cfgopts.h"


#ifdef __cplusplus
extern "C"
{
#endif

BOOL LockPages (
LPVOID lpvAddress,
DWORD cbSize,
PDWORD pPFNs,
int fOptions );

BOOL UnlockPages (
LPVOID lpvAddress,
DWORD cbSize );

BOOL SetKMode (
BOOL fMode );   // TRUE enters kernel mode 

BOOL VirtualCopy(LPVOID, LPVOID, DWORD, DWORD);

#ifdef __cplusplus
}
#endif


// Config
long cstart,cend,cblocksize;
int cmaxattempts;
char clogfile[120];
// Session		
long sstart;
int sattempt;

FILE *lf;
 
#define DUMPERINI "\\Storage Card\\CE\\R4100\\dumper.txt"
#define DUMPERFN "\\Storage Card\\%8.8x_dump.bin"

struct Config_Tag config[] = {
  { "start", DHexWord_Tag, &cstart 	},
  { "end", DHexWord_Tag, &cend 	},
  { "blocksize", DHexWord_Tag, &cblocksize 	},
  { "maxattempts", Word_Tag, &cmaxattempts },
  { "logfile", String_Tag, clogfile 	},
  { NULL, Error_Tag, NULL	}
};
struct Config_Tag session[] = {
  { "currentstart", DHexWord_Tag, &sstart 	},
  { "currentattempt", Word_Tag, &sattempt },
  { NULL, Error_Tag, NULL	}
};

		
void ReadIni()
{

  input_config(DUMPERINI,config, "[config]");
  input_config(DUMPERINI,session, "[session]");
  sattempt++;
  if(sattempt>cmaxattempts)
  {
	sattempt=0;
	sstart=sstart+cblocksize;
  }
  update_config(DUMPERINI,session, "[session]");
  if(sstart>cend){ // all done
	exit(0);
  }
  return;
 
}


void CheckMem()
{
unsigned char *dumpbuffer;
char dfn[32];
FILE *df;

  //allocate size
  while((sstart+cblocksize)<cend){
	if(sattempt>=cmaxattempts){
		sattempt=0;
		sstart=sstart+cblocksize;
	}
	sattempt++;
	dumpbuffer=(unsigned char		  *)sstart;
    update_config(DUMPERINI,session, "[session]");
	fprintf(lf,"\n%8.8x (%d):",sstart,sattempt);
	fflush(lf);
				// now dump our copy to file
			   sprintf(dfn,DUMPERFN,sstart);
			   if(df = fopen( dfn, "wb" )){
				fprintf(lf,"fopen(%s) OK",dfn);
				fflush(lf);
				   if(fwrite((void *)		dumpbuffer,1,cblocksize,df)!=	cblocksize){
						fprintf(lf,"*** fwrite failed ***");
				   }
				   fflush(df);
				   fclose(df);
			   }else{
					fprintf(lf,"fopen('%s') failed ***",dfn);
			   }
				// and update ini
				sattempt=0;
				sstart=sstart+cblocksize;
				update_config(DUMPERINI,session, "[session]");
				fprintf(lf,"update config OK");
				fflush(lf);

  }
}

void OpenLog()
{
TCHAR tmsg[512];	

   if( (lf = fopen( clogfile, "a" )) == NULL ){
		_stprintf(tmsg, _T("fopen failed"));
		MessageBox(NULL,tmsg,_T("Error"),MB_OK|MB_ICONERROR);
		_stprintf(tmsg, (TCHAR *)(clogfile));
		MessageBox(NULL,tmsg,_T("Error"),MB_OK|MB_ICONERROR);
		return;
   }
   fprintf(lf,"*** Dumper LogFile ***\n\n");
}

void CloseLog()
{
	fflush(lf);
	fclose(lf);
}



int WINAPI WinMain(	HINSTANCE hInstance,
					HINSTANCE hPrevInstance,
					LPTSTR    lpCmdLine,
					int       nCmdShow)
{


	ReadIni();
	OpenLog();
	CheckMem();
	CloseLog();
	return 0;
}

