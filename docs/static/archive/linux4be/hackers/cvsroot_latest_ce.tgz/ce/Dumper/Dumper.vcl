<html>
<body>
<pre>
<h1>Build Log</h1>
<h3>
--------------------Configuration: Dumper - Win32 (WCE MIPS) Release--------------------
</h3>
<h3>Command Lines</h3>
Creating temporary file "C:\DOCUME~1\FILIPO~1\LOCALS~1\Temp\RSPD27.tmp" with contents
[
/nologo /W3 /D _WIN32_WCE=300 /D "UNKNOWN" /D "MIPS" /D "_MIPS_" /D UNDER_CE=300 /D "UNICODE" /D "_UNICODE" /D "NDEBUG" /Fp"MIPSRel/Dumper.pch" /Yu"stdafx.h" /Fo"MIPSRel/" /Oxs /MC /c 
"C:\data\projects\linux4.be\src\ce\Dumper\Dumper.cpp"
]
Creating command line "clmips.exe @C:\DOCUME~1\FILIPO~1\LOCALS~1\Temp\RSPD27.tmp" 
Creating temporary file "C:\DOCUME~1\FILIPO~1\LOCALS~1\Temp\RSPD28.tmp" with contents
[
commctrl.lib coredll.lib /nologo /base:"0x00010000" /stack:0x10000,0x1000 /entry:"WinMainCRTStartup" /incremental:no /pdb:"MIPSRel/Dumper.pdb" /nodefaultlib:"libc.lib /nodefaultlib:libcd.lib /nodefaultlib:libcmt.lib /nodefaultlib:libcmtd.lib /nodefaultlib:msvcrt.lib /nodefaultlib:msvcrtd.lib" /out:"MIPSRel/Dumper.exe" /subsystem:windowsce,3.00 /MACHINE:MIPS 
.\MIPSRel\cfgopts.obj
.\MIPSRel\Dumper.obj
.\MIPSRel\StdAfx.obj
.\MIPSRel\Dumper.res
]
Creating command line "link.exe @C:\DOCUME~1\FILIPO~1\LOCALS~1\Temp\RSPD28.tmp"
<h3>Output Window</h3>
Compiling...
Dumper.cpp
C:\data\projects\linux4.be\src\ce\Dumper\Dumper.cpp(134) : warning C4018: '!=' : signed/unsigned mismatch
Linking...



<h3>Results</h3>
Dumper.exe - 0 error(s), 1 warning(s)
</pre>
</body>
</html>
