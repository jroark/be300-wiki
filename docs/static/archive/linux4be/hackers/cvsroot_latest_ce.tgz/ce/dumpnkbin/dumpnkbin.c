/* 
 * $Id: dumpnkbin.c,v 1.1 2004/09/13 20:54:17 filip Exp $
 *
 
    * From: Holger Schurig
    * Subject: dumpnkbin.c
    * Date: Fri, 22 Jun 2001 05:59:48 -0700 

Here is the file that dumps some info from an Windows CE nk.bin, maybe 
it can help others when they want to port a free Operating System to 
some platform.

Greetings,

-- 
MN-Logistik GmbH         http://www.mn-logistik.de
Holger Schurig           Network Administrator
Dieselstr. 18
61191 Rosbach v.d.H�he
Tel: 06003/9141-0        Fax: 06003/9141-49
*/

#include <stdio.h>
#include <string.h>
#include <unistd.h>

#define min(a,b) (a) < (b) ? (a) : (b)
 
void usage(char *argv[])
{
   printf("Usage: %s [-w] <filename>\n", argv[0]);
   exit(1);
}


int main(int argc, char *argv[])
{
    // Option handling
    int do_write = 0;
    char ext[80];

    // nk.bin parsing
    FILE *f;
    char readheader[7];
    char wantheader[] = "B000FF\n";
    size_t bytesread;

    // Image handling
    int pos;
    int addr;
    int length;
    int chksum;

    // output handling
    FILE *f_out;
    char buffer[8192];


    //
    //  Initialisation
    //
    strcpy(ext, "img");


    //
    //  Check for command line options
    //
    while (1) {
        int c = getopt(argc, argv, "we");
        if (c == -1)
            break;

        switch (c) {
        case 'w':		// write files
            do_write = 1;
            break;
        case 'e':		// extension
            //strncpy(ext, sizeof(ext), optarg);
            break;
        default:
            usage(argv);
            break;
        }
    }
        
    if (argc < 2 || argc == optind)
       usage(argv);
       

    ////////////////////////////////////////////////////////////
   
    //
    //  Open input file
    //
    f = fopen(argv[optind], "rb");
    if (!f) {
   	printf("Could not open file %s\n", argv[optind]);
   	return 1;
    }
    
    //
    // Check header
    //
    bytesread = fread(readheader, 1, sizeof(readheader), f);
    if (bytesread != sizeof(readheader)) {
    	printf("Could not read header BOO0FF header (bytesread = %d)\n", bytesread);
    	return 1;
    }
    if (memcmp(readheader, wantheader, sizeof(readheader)) ) {
    	printf("Header is not %s", wantheader);
    	return 1;
    }
    
    ////////////////////////////////////////////////////////////

    //
    // Display contents
    //
    bytesread = fread(&addr,   1, sizeof(addr), f);
    bytesread = fread(&length, 1, sizeof(length), f);
    printf("Flash file       %s\n", argv[optind]);
    printf("Flash address    0x%08x\n", addr);
    printf("Flash length     0x%08x\n\n", length);

    while (1) {
        pos = ftell(f);
        bytesread = fread(&addr, 1, sizeof(addr), f);
        if (bytesread != sizeof(addr)) { printf("Could not read image address\n"); return 1; }
        bytesread = fread(&length, 1, sizeof(length), f);
        if (bytesread != sizeof(length)) { printf("Could not read image length\n"); return 1; }
        bytesread = fread(&chksum, 1, sizeof(chksum), f);
        if (bytesread != sizeof(chksum)) { printf("Could not read image checksum\n"); return 1; }
       
        printf("file pos 0x%08x at addr 0x%08x leng 0x%08x xsum 0x%08x\n", pos, addr, length, chksum);

	// End of file?
        if (addr == 0 && chksum == 0)
            break;

	//
	// Do we want output files?
	//
	
        if (do_write) {
            pos = length;
            snprintf(buffer, sizeof(buffer), "%08x.img", addr);
            f_out = fopen( buffer, "wb");
            while (pos) {
                bytesread = fread(buffer, 1, min(sizeof(buffer),pos), f);
                fwrite(buffer, 1, bytesread, f_out);
                pos -= bytesread;
            }
            fclose(f_out);
        } else {
            pos = ftell(f);
            fseek(f, pos+length, SEEK_SET);
        }
    }

    printf("\n");
    return 0;
}
