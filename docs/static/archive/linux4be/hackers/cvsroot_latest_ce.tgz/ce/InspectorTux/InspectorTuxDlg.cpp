// Project: Linux4.BE
// Copyright � 2002 Filip Onkelinx
//
// http://www.linux4.BE/
// filip@linux4.BE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA. 
//
// 
// $Workfile: $  
// $Author: fon $  
// $Date: 2002/02/19 22:20:34 $
// $Revision: 1.3 $
// 
// $Header: /home/cvsroot/ce/InspectorTux/InspectorTuxDlg.cpp,v 1.3 2002/02/19 22:20:34 fon Exp $
// 
// -------------------------------------------------------------------------------

#include "stdafx.h"
#include "InspectorTux.h"
#include "InspectorTuxDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern void DrawPixels();
extern void SysInfo();

/////////////////////////////////////////////////////////////////////////////
// CInspectorTuxDlg dialog

CInspectorTuxDlg::CInspectorTuxDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CInspectorTuxDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CInspectorTuxDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CInspectorTuxDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CInspectorTuxDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CInspectorTuxDlg, CDialog)
	//{{AFX_MSG_MAP(CInspectorTuxDlg)
	ON_BN_CLICKED(IDCANCEL, OnExit)
	ON_BN_CLICKED(IDVIDEO, OnVideo)
	ON_BN_CLICKED(IDSERIAL, OnSerial)
	ON_BN_CLICKED(IDSYSINFO, OnSysInfo)
	ON_BN_CLICKED(IDRAM, OnRam)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CInspectorTuxDlg message handlers

BOOL CInspectorTuxDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	CenterWindow(GetDesktopWindow());	// center to the hpc screen

	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}



void CInspectorTuxDlg::OnExit() 
{
	// TODO: Add your control notification handler code here
	exit(0);
}

void CInspectorTuxDlg::OnVideo() 
{
	// TODO: Add your control notification handler code here
	DrawPixels();

}

void CInspectorTuxDlg::OnSerial() 
{
	// TODO: Add your control notification handler code here
	
}

void CInspectorTuxDlg::OnSysInfo() 
{
	// TODO: Add your control notification handler code here
	SysInfo();
}

void CInspectorTuxDlg::OnRam() 
{
	// TODO: Add your control notification handler code here
	
}

