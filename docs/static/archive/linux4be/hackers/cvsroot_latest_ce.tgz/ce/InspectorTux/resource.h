//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by InspectorTux.rc
//
#define IDVIDEO                         3
#define IDSYSINFO                       4
#define IDSERIAL                        5
#define IDRAM                           6
#define IDABOUT                         7
#define IDD_INSPECTORTUX_DIALOG         102
#define IDD_ABOUTBOX                    103
#define IDR_MAINFRAME                   128
#define IDC_COPYRIGHT                   1000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
