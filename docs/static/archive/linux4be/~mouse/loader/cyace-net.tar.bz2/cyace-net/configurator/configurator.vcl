<html>
<body>
<pre>
<h1>Build Log</h1>
<h3>
--------------------Configuration: configurator - Win32 (WCE MIPS) Release--------------------
</h3>
<h3>Command Lines</h3>




<h3>Results</h3>
configurator.exe - 0 error(s), 0 warning(s)
<h3>
--------------------Configuration: loader - Win32 (WCE MIPS) Release--------------------
</h3>
<h3>Command Lines</h3>
Creating temporary file "C:\TEMP\RSP63.tmp" with contents
[
/nologo /W3 /O2 /I "..\include" /D _WIN32_WCE=211 /D "NDEBUG" /D "MIPS" /D "_MIPS_" /D UNDER_CE=211 /D "UNICODE" /D "WIN32_PLATFORM_PSPC" /D "_UNICODE" /Fp"WMIPSRel/loader.pch" /YX /Fo"WMIPSRel/" /MC /c 
"D:\cyace\loader\loader.cpp"
]
Creating command line "clmips.exe @C:\TEMP\RSP63.tmp" 
Creating temporary file "C:\TEMP\RSP64.tmp" with contents
[
commctrl.lib coredll.lib winsock.lib wininet.lib /nologo /stack:0x10000,0x1000 /incremental:no /pdb:"WMIPSRel/loader.pdb" /nodefaultlib:"libc.lib /nodefaultlib:libcd.lib /nodefaultlib:libcmt.lib /nodefaultlib:libcmtd.lib /nodefaultlib:msvcrt.lib /nodefaultlib:msvcrtd.lib" /out:"WMIPSRel/loader.exe" /machine:MIPS /subsystem:windowsce,2.11 
.\WMIPSRel\loader.obj
.\WMIPSRel\main.obj
".\WMIPSRel\mips-pr31700.obj"
".\WMIPSRel\mips-vr41xx.obj"
.\WMIPSRel\loader.res
\cyace\lib\WMIPSRel\lib.lib
\cyace\pbsdboot\WMIPSRel\pbsdboot.lib
]
Creating command line "link.exe @C:\TEMP\RSP64.tmp"
<h3>Output Window</h3>
Compiling...
loader.cpp
Linking...




<h3>Results</h3>
loader.exe - 0 error(s), 0 warning(s)
</pre>
</body>
</html>
