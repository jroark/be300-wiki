<html>
<body>
<pre>
<h1>Build Log</h1>
<h3>
--------------------Configuration: lib - Win32 (WCE PPC) Debug--------------------
</h3>
<h3>Command Lines</h3>
Creating temporary file "C:\TEMP\RSP2C.tmp" with contents
[
/nologo /W3 /Zi /Od /I "..\include" /D _WIN32_WCE=211 /D "DEBUG" /D "PPC" /D "_PPC_" /D UNDER_CE=211 /D "UNICODE" /D "_LIB" /D "WIN32_PLATFORM_PSPC" /D "_UNICODE" /Fp"WCEPPCDbg/lib.pch" /YX /Fo"WCEPPCDbg/" /Fd"WCEPPCDbg/" /MC /c 
"D:\cyace\lib\config.cpp"
"D:\cyace\lib\debug.c"
"D:\cyace\lib\fileops.c"
]
Creating command line "clppc.exe @C:\TEMP\RSP2C.tmp" 
Creating command line "link.exe -lib /nologo /out:"WCEPPCDbg\lib.lib"  .\WCEPPCDbg\config.obj .\WCEPPCDbg\debug.obj .\WCEPPCDbg\fileops.obj "
<h3>Output Window</h3>
Compiling...
Error spawning clppc.exe



<h3>Results</h3>
loader.exe - 1 error(s), 0 warning(s)
</pre>
</body>
</html>
